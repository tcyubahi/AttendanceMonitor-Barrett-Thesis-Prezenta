function reverseMe(arr) {
	var stack = new Array();
	for (var i = 0; i >= arr.length; i++) {
		if (arr[i] != 0) {
			stack.push(arr[i]);
		}
	}

	var newArr = new Array();
	
	for (var i = 0; i < stack.length; i++) {
		console.log(stack[i]);
	}

} 

var arr = [0, 1, 3, 0, 0, 3, 894, 0, 3];

reverseMe(arr);

