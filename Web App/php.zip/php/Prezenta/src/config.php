<?php
define("DB_NAME", "AttendanceMonitor");
define("DB_USER", "root");
define("DB_PASS", "");
?>
